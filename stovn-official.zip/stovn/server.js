/**
 * server.js
 * ----------------------------------------------------------------------
 * Server chinh cho STOVN Official.
 * - Express phuc vu giao dien tinh (HTML/CSS/JS) va REST API.
 * - Socket.IO day du lieu thoi gian thuc: khi admin dang/sua/xoa thong
 *   bao, tuyen dung hoac cap nhat phien ban, moi nguoi dang mo web se
 *   thay ngay lap tuc ma khong can tai lai trang.
 * - Session + bcrypt de bao ve trang quan tri /admin.
 * - Helmet + rate-limit + sanitize-html de chong XSS/CSRF/brute-force.
 * ----------------------------------------------------------------------
 */

require('dotenv').config();

const path = require('path');
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: process.env.NODE_ENV === 'production' ? false : '*' }
});

const PORT = process.env.PORT || 3000;
const isProd = process.env.NODE_ENV === 'production';

// ---------------------------------------------------------------------
// Bao mat co ban
// ---------------------------------------------------------------------
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        // Google Fonts duoc nhung qua the <link>, script/styles chi chay tu chinh site.
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com'],
        scriptSrc: ["'self'"],
        imgSrc: ["'self'", 'data:'],
        connectSrc: ["'self'"]
      }
    }
  })
);
app.use(cors({ origin: isProd ? false : true, credentials: true }));
app.use(express.json({ limit: '200kb' }));
app.use(express.urlencoded({ extended: true, limit: '200kb' }));

app.set('trust proxy', 1);
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'stovn-dev-secret-doi-trong-production',
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: isProd,
      maxAge: 1000 * 60 * 60 * 8 // 8 gio
    }
  })
);

// ---------------------------------------------------------------------
// API routes
// ---------------------------------------------------------------------
app.use('/api/auth', require('./routes/auth'));
app.use('/api/announcements', require('./routes/announcements')(io));
app.use('/api/recruitment', require('./routes/recruitment')(io));
app.use('/api/applications', require('./routes/applications')(io));
app.use('/api/meta', require('./routes/meta')(io));

// ---------------------------------------------------------------------
// Giao dien tinh
// ---------------------------------------------------------------------
app.use(express.static(path.join(__dirname, 'public')));

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin', 'index.html'));
});

app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'Khong tim thay API nay.' });
  }
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ---------------------------------------------------------------------
// Xu ly loi chung
// ---------------------------------------------------------------------
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Da xay ra loi may chu. Vui long thu lai sau.' });
});

// ---------------------------------------------------------------------
// Socket.IO: chi phat (broadcast) su kien, khong nhan lenh thay doi du
// lieu tu client de tranh gia mao. Moi thay doi du lieu phai di qua REST
// API co xac thuc admin ben tren.
// ---------------------------------------------------------------------
io.on('connection', (socket) => {
  socket.emit('connected', { message: 'Da ket noi realtime voi STOVN Official.' });
});

server.listen(PORT, () => {
  console.log(`STOVN Official dang chay tai http://localhost:${PORT}`);
  console.log(`Trang quan tri: http://localhost:${PORT}/admin`);
});
