/**
 * admin/admin.js
 * Toan bo logic cho trang quan tri: dang nhap, CRUD thong bao/tuyen dung,
 * duyet don dang ky, cap nhat phien ban game, va dong bo realtime.
 */
(function () {
  let csrfToken = null;
  const socket = io();

  // --------------------------------------------------------------
  // Ham goi API dung chung, tu dong dinh kem CSRF token khi can
  // --------------------------------------------------------------
  async function apiRequest(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    if (['POST', 'PUT', 'DELETE', 'PATCH'].includes((options.method || 'GET').toUpperCase()) && csrfToken) {
      headers['x-csrf-token'] = csrfToken;
    }
    const res = await fetch(`/api${path}`, { credentials: 'same-origin', headers, ...options });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Da xay ra loi.');
    return data;
  }

  function showToast(message, kind = 'info') {
    const region = document.getElementById('toast-region');
    const el = document.createElement('div');
    el.className = `toast toast-${kind}`;
    el.textContent = message;
    region.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0'; el.style.transition = 'opacity 0.3s ease';
      setTimeout(() => el.remove(), 320);
    }, 3600);
  }

  const loginScreen = document.getElementById('admin-login-screen');
  const dashboard = document.getElementById('admin-dashboard');

  // --------------------------------------------------------------
  // Kiem tra phien dang nhap khi tai trang
  // --------------------------------------------------------------
  async function checkSession() {
    const data = await apiRequest('/auth/session');
    if (data.authenticated) {
      csrfToken = data.csrfToken;
      document.getElementById('admin-username-label').textContent = data.username;
      loginScreen.hidden = true;
      dashboard.hidden = false;
      loadAllTabs();
    } else {
      loginScreen.hidden = false;
      dashboard.hidden = true;
    }
  }

  // --------------------------------------------------------------
  // Dang nhap / dang xuat
  // --------------------------------------------------------------
  document.getElementById('admin-login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const errorEl = document.getElementById('login-error');
    errorEl.hidden = true;
    try {
      const data = await apiRequest('/auth/login', {
        method: 'POST',
        body: JSON.stringify({
          username: document.getElementById('login-username').value,
          password: document.getElementById('login-password').value
        })
      });
      csrfToken = data.csrfToken;
      await checkSession();
    } catch (err) {
      errorEl.textContent = err.message;
      errorEl.hidden = false;
    }
  });

  document.getElementById('admin-logout-btn').addEventListener('click', async () => {
    await apiRequest('/auth/logout', { method: 'POST' });
    csrfToken = null;
    window.location.reload();
  });

  // --------------------------------------------------------------
  // Chuyen tab
  // --------------------------------------------------------------
  document.querySelectorAll('.admin-tab').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.admin-tab').forEach((b) => b.classList.remove('active'));
      document.querySelectorAll('.admin-panel').forEach((p) => { p.hidden = true; });
      btn.classList.add('active');
      document.getElementById(`tab-${btn.dataset.tab}`).hidden = false;
    });
  });

  function loadAllTabs() {
    loadAnnouncements();
    loadRecruitments();
    loadApplications();
    loadMeta();
  }

  // --------------------------------------------------------------
  // TAB: Thong bao
  // --------------------------------------------------------------
  const announcementOverlay = document.getElementById('announcement-modal-overlay');
  const announcementForm = document.getElementById('announcement-form');

  async function loadAnnouncements() {
    const tbody = document.querySelector('#announcements-table tbody');
    tbody.innerHTML = '<tr class="admin-empty-row"><td colspan="5">Dang tai...</td></tr>';
    try {
      const data = await apiRequest('/announcements');
      if (!data.items.length) {
        tbody.innerHTML = '<tr class="admin-empty-row"><td colspan="5">Chua co thong bao nao.</td></tr>';
        return;
      }
      tbody.innerHTML = data.items.map((item) => `
        <tr data-id="${item.id}">
          <td>${STOVN_VIEWS.escapeHtml(item.title)}</td>
          <td>${STOVN_VIEWS.TYPE_LABELS[item.type] || item.type}</td>
          <td>${STOVN_VIEWS.escapeHtml(item.author)}</td>
          <td>${STOVN_VIEWS.formatDate(item.createdAt)}</td>
          <td class="cell-actions">
            <button class="btn btn-ghost btn-sm" data-edit-announcement="${item.id}">Sua</button>
            <button class="btn btn-danger btn-sm" data-delete-announcement="${item.id}">Xoa</button>
          </td>
        </tr>
      `).join('');
      wireAnnouncementRowActions(data.items);
    } catch (err) {
      tbody.innerHTML = `<tr class="admin-empty-row"><td colspan="5">${STOVN_VIEWS.escapeHtml(err.message)}</td></tr>`;
    }
  }

  function wireAnnouncementRowActions(items) {
    document.querySelectorAll('[data-edit-announcement]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const item = items.find((i) => i.id === btn.dataset.editAnnouncement);
        openAnnouncementModal(item);
      });
    });
    document.querySelectorAll('[data-delete-announcement]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        if (!confirm('Ban co chac muon xoa thong bao nay?')) return;
        try {
          await apiRequest(`/announcements/${btn.dataset.deleteAnnouncement}`, { method: 'DELETE' });
          showToast('Da xoa thong bao.', 'success');
          loadAnnouncements();
        } catch (err) { showToast(err.message, 'error'); }
      });
    });
  }

  function openAnnouncementModal(item) {
    document.getElementById('announcement-modal-title').textContent = item ? 'Chinh sua thong bao' : 'Dang thong bao moi';
    document.getElementById('announcement-id').value = item ? item.id : '';
    document.getElementById('announcement-title-input').value = item ? item.title : '';
    document.getElementById('announcement-type-input').value = item ? item.type : 'quan-trong';
    document.getElementById('announcement-author-input').value = item ? item.author : '';
    document.getElementById('announcement-content-input').value = item ? item.content : '';
    announcementOverlay.classList.add('open');
  }
  document.getElementById('btn-new-announcement').addEventListener('click', () => openAnnouncementModal(null));

  announcementForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('announcement-id').value;
    const payload = {
      title: document.getElementById('announcement-title-input').value,
      type: document.getElementById('announcement-type-input').value,
      author: document.getElementById('announcement-author-input').value,
      content: document.getElementById('announcement-content-input').value
    };
    try {
      if (id) {
        await apiRequest(`/announcements/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
        showToast('Da cap nhat thong bao.', 'success');
      } else {
        await apiRequest('/announcements', { method: 'POST', body: JSON.stringify(payload) });
        showToast('Da dang thong bao moi.', 'success');
      }
      announcementOverlay.classList.remove('open');
      loadAnnouncements();
    } catch (err) { showToast(err.message, 'error'); }
  });

  // --------------------------------------------------------------
  // TAB: Tuyen dung
  // --------------------------------------------------------------
  const recruitmentOverlay = document.getElementById('recruitment-modal-overlay');
  const recruitmentForm = document.getElementById('recruitment-form');

  async function loadRecruitments() {
    const tbody = document.querySelector('#recruitment-table tbody');
    tbody.innerHTML = '<tr class="admin-empty-row"><td colspan="4">Dang tai...</td></tr>';
    try {
      const data = await apiRequest('/recruitment');
      if (!data.items.length) {
        tbody.innerHTML = '<tr class="admin-empty-row"><td colspan="4">Chua co dot tuyen dung nao.</td></tr>';
        return;
      }
      tbody.innerHTML = data.items.map((item) => `
        <tr data-id="${item.id}">
          <td>${STOVN_VIEWS.escapeHtml(item.position)}</td>
          <td>${STOVN_VIEWS.formatDate(item.deadline)}</td>
          <td>${STOVN_VIEWS.STATUS_LABELS[item.status] || item.status}</td>
          <td class="cell-actions">
            <button class="btn btn-ghost btn-sm" data-edit-recruitment="${item.id}">Sua</button>
            <button class="btn btn-danger btn-sm" data-delete-recruitment="${item.id}">Xoa</button>
          </td>
        </tr>
      `).join('');
      wireRecruitmentRowActions(data.items);
    } catch (err) {
      tbody.innerHTML = `<tr class="admin-empty-row"><td colspan="4">${STOVN_VIEWS.escapeHtml(err.message)}</td></tr>`;
    }
  }

  function wireRecruitmentRowActions(items) {
    document.querySelectorAll('[data-edit-recruitment]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const item = items.find((i) => i.id === btn.dataset.editRecruitment);
        openRecruitmentModal(item);
      });
    });
    document.querySelectorAll('[data-delete-recruitment]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        if (!confirm('Ban co chac muon xoa dot tuyen dung nay?')) return;
        try {
          await apiRequest(`/recruitment/${btn.dataset.deleteRecruitment}`, { method: 'DELETE' });
          showToast('Da xoa dot tuyen dung.', 'success');
          loadRecruitments();
        } catch (err) { showToast(err.message, 'error'); }
      });
    });
  }

  function toDatetimeLocalValue(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  function openRecruitmentModal(item) {
    document.getElementById('recruitment-modal-title').textContent = item ? 'Chinh sua tuyen dung' : 'Dang dot tuyen dung moi';
    document.getElementById('recruitment-id').value = item ? item.id : '';
    document.getElementById('recruitment-position-input').value = item ? item.position : '';
    document.getElementById('recruitment-requirements-input').value = item ? item.requirements : '';
    document.getElementById('recruitment-benefits-input').value = item ? item.benefits : '';
    document.getElementById('recruitment-deadline-input').value = item ? toDatetimeLocalValue(item.deadline) : '';
    document.getElementById('recruitment-status-input').value = item ? item.status : 'dang-mo';
    recruitmentOverlay.classList.add('open');
  }
  document.getElementById('btn-new-recruitment').addEventListener('click', () => openRecruitmentModal(null));

  recruitmentForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('recruitment-id').value;
    const deadlineVal = document.getElementById('recruitment-deadline-input').value;
    const payload = {
      position: document.getElementById('recruitment-position-input').value,
      requirements: document.getElementById('recruitment-requirements-input').value,
      benefits: document.getElementById('recruitment-benefits-input').value,
      deadline: deadlineVal ? new Date(deadlineVal).toISOString() : null,
      status: document.getElementById('recruitment-status-input').value
    };
    try {
      if (id) {
        await apiRequest(`/recruitment/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
        showToast('Da cap nhat dot tuyen dung.', 'success');
      } else {
        await apiRequest('/recruitment', { method: 'POST', body: JSON.stringify(payload) });
        showToast('Da dang dot tuyen dung moi.', 'success');
      }
      recruitmentOverlay.classList.remove('open');
      loadRecruitments();
    } catch (err) { showToast(err.message, 'error'); }
  });

  // --------------------------------------------------------------
  // TAB: Don dang ky
  // --------------------------------------------------------------
  const STATUS_LABELS_APP = { 'cho-duyet': 'Cho duyet', 'da-duyet': 'Da duyet', 'tu-choi': 'Tu choi' };

  async function loadApplications() {
    const tbody = document.querySelector('#applications-table tbody');
    const statusFilter = document.getElementById('application-status-filter').value;
    tbody.innerHTML = '<tr class="admin-empty-row"><td colspan="7">Dang tai...</td></tr>';
    try {
      const data = await apiRequest(`/applications${statusFilter ? `?status=${statusFilter}` : ''}`);
      if (!data.items.length) {
        tbody.innerHTML = '<tr class="admin-empty-row"><td colspan="7">Chua co don dang ky nao.</td></tr>';
        return;
      }
      tbody.innerHTML = data.items.map((item) => `
        <tr data-id="${item.id}">
          <td>${STOVN_VIEWS.escapeHtml(item.robloxName)}</td>
          <td>${STOVN_VIEWS.escapeHtml(item.discordName)}</td>
          <td>${STOVN_VIEWS.escapeHtml(item.currentRank)}</td>
          <td>${item.age}</td>
          <td class="cell-truncate" title="${STOVN_VIEWS.escapeHtml(item.reason)}">${STOVN_VIEWS.escapeHtml(item.reason)}</td>
          <td>${STATUS_LABELS_APP[item.status] || item.status}</td>
          <td class="cell-actions">
            <button class="btn btn-ghost btn-sm" data-approve-app="${item.id}" ${item.status === 'da-duyet' ? 'disabled' : ''}>Duyet</button>
            <button class="btn btn-ghost btn-sm" data-reject-app="${item.id}" ${item.status === 'tu-choi' ? 'disabled' : ''}>Tu choi</button>
            <button class="btn btn-danger btn-sm" data-delete-app="${item.id}">Xoa</button>
          </td>
        </tr>
      `).join('');
      wireApplicationRowActions();
    } catch (err) {
      tbody.innerHTML = `<tr class="admin-empty-row"><td colspan="7">${STOVN_VIEWS.escapeHtml(err.message)}</td></tr>`;
    }
  }

  function wireApplicationRowActions() {
    document.querySelectorAll('[data-approve-app]').forEach((btn) => {
      btn.addEventListener('click', () => updateApplicationStatus(btn.dataset.approveApp, 'da-duyet'));
    });
    document.querySelectorAll('[data-reject-app]').forEach((btn) => {
      btn.addEventListener('click', () => updateApplicationStatus(btn.dataset.rejectApp, 'tu-choi'));
    });
    document.querySelectorAll('[data-delete-app]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        if (!confirm('Ban co chac muon xoa don dang ky nay?')) return;
        try {
          await apiRequest(`/applications/${btn.dataset.deleteApp}`, { method: 'DELETE' });
          showToast('Da xoa don dang ky.', 'success');
          loadApplications();
        } catch (err) { showToast(err.message, 'error'); }
      });
    });
  }

  async function updateApplicationStatus(id, status) {
    try {
      await apiRequest(`/applications/${id}`, { method: 'PUT', body: JSON.stringify({ status }) });
      showToast('Da cap nhat trang thai don dang ky.', 'success');
      loadApplications();
    } catch (err) { showToast(err.message, 'error'); }
  }

  document.getElementById('application-status-filter').addEventListener('change', loadApplications);

  // --------------------------------------------------------------
  // TAB: Phien ban game
  // --------------------------------------------------------------
  async function loadMeta() {
    try {
      const meta = await apiRequest('/meta');
      document.getElementById('meta-version-input').value = meta.gameVersion;
    } catch (err) { /* bo qua */ }
  }
  document.getElementById('meta-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await apiRequest('/meta', {
        method: 'PUT',
        body: JSON.stringify({ gameVersion: document.getElementById('meta-version-input').value })
      });
      showToast('Da cap nhat phien ban game.', 'success');
    } catch (err) { showToast(err.message, 'error'); }
  });

  // --------------------------------------------------------------
  // Dong modal chung
  // --------------------------------------------------------------
  document.querySelectorAll('[data-close-modal]').forEach((btn) => {
    btn.addEventListener('click', () => document.getElementById(btn.dataset.closeModal).classList.remove('open'));
  });
  document.querySelectorAll('.modal-overlay').forEach((overlay) => {
    overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.classList.remove('open'); });
  });

  // --------------------------------------------------------------
  // Realtime: tu dong lam moi bang khi co thay doi tu noi khac
  // --------------------------------------------------------------
  socket.on('announcement:new', () => loadAnnouncements());
  socket.on('announcement:update', () => loadAnnouncements());
  socket.on('announcement:delete', () => loadAnnouncements());
  socket.on('recruitment:new', () => loadRecruitments());
  socket.on('recruitment:update', () => loadRecruitments());
  socket.on('recruitment:delete', () => loadRecruitments());
  socket.on('application:new-for-admin', () => {
    showToast('Co don dang ky moi vua duoc gui.', 'info');
    loadApplications();
  });
  socket.on('application:update-for-admin', () => loadApplications());
  socket.on('application:delete-for-admin', () => loadApplications());

  checkSession();
})();
