/**
 * js/main.js
 * Dieu khien chinh: dinh tuyen theo hash, nhan dien thiet bi (dien thoai/
 * may tinh), gan su kien menu, modal, toast va cap nhat realtime.
 */
(function () {
  const appRoot = document.getElementById('app-root');
  const loadingScreen = document.getElementById('loading-screen');

  // ------------------------------------------------------------------
  // 1. Nhan dien thiet bi: dien thoai hien giao dien Mobile,
  //    may tinh hien giao dien Desktop (khong chi dua vao be rong man hinh).
  // ------------------------------------------------------------------
  function detectDevice() {
    const isCoarsePointer = window.matchMedia('(pointer: coarse)').matches;
    const isNarrow = window.innerWidth <= 820;
    const uaMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
    return (isCoarsePointer && isNarrow) || (uaMobile && isNarrow) ? 'mobile' : 'desktop';
  }

  function applyDeviceClass() {
    const device = detectDevice();
    document.body.classList.remove('device-mobile', 'device-desktop');
    document.body.classList.add(device === 'mobile' ? 'device-mobile' : 'device-desktop');
  }
  applyDeviceClass();
  window.addEventListener('resize', debounce(applyDeviceClass, 200));

  function debounce(fn, wait) {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), wait); };
  }

  // ------------------------------------------------------------------
  // 2. Man hinh tai
  // ------------------------------------------------------------------
  window.addEventListener('load', () => {
    setTimeout(() => loadingScreen.classList.add('hidden'), 500);
  });

  // ------------------------------------------------------------------
  // 3. Toast thong bao ngan
  // ------------------------------------------------------------------
  function showToast(message, kind = 'info') {
    const region = document.getElementById('toast-region');
    const el = document.createElement('div');
    el.className = `toast toast-${kind}`;
    el.textContent = message;
    region.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transition = 'opacity 0.3s ease';
      setTimeout(() => el.remove(), 320);
    }, 3600);
  }

  // ------------------------------------------------------------------
  // 4. Dinh tuyen (routing) don gian dua tren hash
  // ------------------------------------------------------------------
  const routes = {
    'trang-chu': () => STOVN_VIEWS.home(),
    'thong-bao': (params) => STOVN_VIEWS.announcementsList(params),
    'tuyen-dung': () => STOVN_VIEWS.recruitmentList(),
    'cap-nhat': () => STOVN_VIEWS.updates(),
    'su-kien': () => STOVN_VIEWS.events(),
    'noi-quy': () => Promise.resolve(STOVN_VIEWS.rules()),
    'huong-dan': () => Promise.resolve(STOVN_VIEWS.guide()),
    'lien-he': () => Promise.resolve(STOVN_VIEWS.contact())
  };

  function parseHash() {
    const raw = window.location.hash.replace(/^#\//, '') || 'trang-chu';
    const [route, queryString] = raw.split('?');
    const params = Object.fromEntries(new URLSearchParams(queryString || ''));
    return { route: route || 'trang-chu', params };
  }

  function setActiveNav(route) {
    document.querySelectorAll('[data-route]').forEach((el) => {
      el.classList.toggle('active', el.dataset.route === route);
    });
  }

  async function render() {
    const { route, params } = parseHash();

    if (route === 'admin-hint') {
      window.location.href = '/admin';
      return;
    }

    const handler = routes[route] || routes['trang-chu'];
    setActiveNav(routes[route] ? route : 'trang-chu');
    appRoot.innerHTML = '<div class="empty-state"><span class="mark">DANG TAI</span><p>Vui long doi trong giay lat...</p></div>';
    try {
      const html = await handler(params);
      appRoot.innerHTML = html;
    } catch (err) {
      appRoot.innerHTML = `<div class="empty-state glass-panel"><span class="mark">LOI</span><p>${STOVN_VIEWS.escapeHtml(err.message || 'Da xay ra loi.')}</p></div>`;
    }
    window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
    closeMobileMenus();
    wireViewInteractions(route);
  }

  window.addEventListener('hashchange', render);
  document.addEventListener('DOMContentLoaded', render);

  // ------------------------------------------------------------------
  // 5. Menu di dong: mo/dong bang "xem them"
  // ------------------------------------------------------------------
  const moreToggle = document.getElementById('mobile-more-toggle');
  const moreSheet = document.getElementById('mobile-more-sheet');
  if (moreToggle) {
    moreToggle.addEventListener('click', (e) => {
      e.stopPropagation();
      moreSheet.classList.toggle('open');
    });
  }
  document.addEventListener('click', (e) => {
    if (moreSheet && moreSheet.classList.contains('open') && !moreSheet.contains(e.target) && e.target !== moreToggle) {
      moreSheet.classList.remove('open');
    }
  });
  function closeMobileMenus() {
    if (moreSheet) moreSheet.classList.remove('open');
  }

  // Menu hamburger cho man hinh trung binh (neu can thu gon)
  const menuToggle = document.getElementById('menu-toggle');
  const mainNav = document.getElementById('main-nav');
  if (menuToggle) {
    menuToggle.addEventListener('click', () => {
      const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
      menuToggle.setAttribute('aria-expanded', String(!expanded));
      mainNav.classList.toggle('open');
    });
  }

  // ------------------------------------------------------------------
  // 6. Tuong tac rieng cho tung view (tim kiem, loc, mo modal)
  // ------------------------------------------------------------------
  function wireViewInteractions(route) {
    // Tim kiem & loc thong bao
    const searchInput = document.getElementById('announcement-search');
    const filterSelect = document.getElementById('announcement-filter');
    if (searchInput || filterSelect) {
      const triggerSearch = debounce(() => {
        const params = new URLSearchParams();
        if (searchInput && searchInput.value) params.set('search', searchInput.value);
        if (filterSelect && filterSelect.value) params.set('type', filterSelect.value);
        const qs = params.toString();
        window.location.hash = `#/thong-bao${qs ? `?${qs}` : ''}`;
      }, 350);
      if (searchInput) searchInput.addEventListener('input', triggerSearch);
      if (filterSelect) filterSelect.addEventListener('change', triggerSearch);
    }

    // Mo modal xem chi tiet thong bao
    document.querySelectorAll('[data-open-announcement]').forEach((el) => {
      el.addEventListener('click', () => openAnnouncementDetail(el.dataset.openAnnouncement));
      el.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') openAnnouncementDetail(el.dataset.openAnnouncement);
      });
    });

    // Mo modal dang ky tuyen dung
    document.querySelectorAll('[data-open-apply]').forEach((el) => {
      el.addEventListener('click', () => openApplyModal(el.dataset.openApply, el.dataset.position));
    });
  }

  // ------------------------------------------------------------------
  // 7. Modal: xem chi tiet thong bao
  // ------------------------------------------------------------------
  const detailOverlay = document.getElementById('detail-modal-overlay');
  async function openAnnouncementDetail(id) {
    try {
      const item = await STOVN_API.getAnnouncement(id);
      document.getElementById('detail-modal-type').textContent = STOVN_VIEWS.TYPE_LABELS[item.type] || item.type;
      document.getElementById('detail-modal-type').className = `badge badge-${item.type}`;
      document.getElementById('detail-modal-title').textContent = item.title;
      document.getElementById('detail-modal-meta').textContent = `${item.author} • ${STOVN_VIEWS.formatDate(item.createdAt)}`;
      document.getElementById('detail-modal-content').textContent = item.content;
      detailOverlay.classList.add('open');
    } catch (err) {
      showToast('Khong the tai chi tiet thong bao.', 'error');
    }
  }
  document.getElementById('detail-modal-close').addEventListener('click', () => detailOverlay.classList.remove('open'));
  detailOverlay.addEventListener('click', (e) => { if (e.target === detailOverlay) detailOverlay.classList.remove('open'); });

  // ------------------------------------------------------------------
  // 8. Modal: dang ky tuyen dung
  // ------------------------------------------------------------------
  const applyOverlay = document.getElementById('apply-modal-overlay');
  const applyForm = document.getElementById('apply-form');

  function openApplyModal(recruitmentId, position) {
    document.getElementById('apply-recruitment-id').value = recruitmentId;
    document.getElementById('apply-modal-position').textContent = `Vi tri: ${position}`;
    applyForm.reset();
    applyOverlay.classList.add('open');
  }
  document.getElementById('apply-modal-close').addEventListener('click', () => applyOverlay.classList.remove('open'));
  applyOverlay.addEventListener('click', (e) => { if (e.target === applyOverlay) applyOverlay.classList.remove('open'); });

  applyForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const submitBtn = applyForm.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Dang gui...';
    try {
      await STOVN_API.submitApplication({
        recruitmentId: document.getElementById('apply-recruitment-id').value,
        robloxName: document.getElementById('apply-roblox').value,
        discordName: document.getElementById('apply-discord').value,
        currentRank: document.getElementById('apply-rank').value,
        age: document.getElementById('apply-age').value,
        reason: document.getElementById('apply-reason').value
      });
      showToast('Da gui don dang ky thanh cong. Cam on ban da quan tam!', 'success');
      applyOverlay.classList.remove('open');
    } catch (err) {
      showToast(err.message || 'Gui don that bai, vui long thu lai.', 'error');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Gui don dang ky';
    }
  });

  // Dong modal bang phim Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      detailOverlay.classList.remove('open');
      applyOverlay.classList.remove('open');
    }
  });

  // ------------------------------------------------------------------
  // 9. Thanh ticker truc tiep — hien thi thong bao moi nhat
  // ------------------------------------------------------------------
  const tickerContent = document.getElementById('ticker-content');
  async function loadTickerInitial() {
    try {
      const data = await STOVN_API.getAnnouncements();
      if (data.items.length) {
        setTicker(data.items[0]);
      } else {
        tickerContent.textContent = 'Chua co thong bao nao duoc dang.';
      }
    } catch (e) {
      tickerContent.textContent = 'Khong the tai thong bao truc tiep.';
    }
  }
  function setTicker(item) {
    tickerContent.textContent = `${STOVN_VIEWS.TYPE_LABELS[item.type] || item.type} — ${item.title}`;
  }
  loadTickerInitial();

  // ------------------------------------------------------------------
  // 10. Realtime: cap nhat giao dien ngay khi admin dang/sua/xoa noi dung
  // ------------------------------------------------------------------
  document.addEventListener('stovn:announcement-new', (e) => {
    setTicker(e.detail);
    showToast(`Thong bao moi: ${e.detail.title}`, 'info');
    refreshCurrentView();
  });
  document.addEventListener('stovn:announcement-update', () => refreshCurrentView());
  document.addEventListener('stovn:announcement-delete', () => refreshCurrentView());
  document.addEventListener('stovn:recruitment-new', () => {
    showToast('Co dot tuyen dung moi vua duoc dang.', 'info');
    refreshCurrentView();
  });
  document.addEventListener('stovn:recruitment-update', () => refreshCurrentView());
  document.addEventListener('stovn:recruitment-delete', () => refreshCurrentView());
  document.addEventListener('stovn:meta-update', (e) => {
    const versionEl = document.getElementById('home-version');
    if (versionEl) versionEl.textContent = e.detail.gameVersion;
    const footerVersion = document.getElementById('footer-version');
    if (footerVersion) footerVersion.textContent = `Phien ban ${e.detail.gameVersion}`;
  });

  function refreshCurrentView() {
    // Chi render lai neu dang o mot view co du lieu dong (khong lam gian doan modal dang mo)
    const { route } = parseHash();
    if (['trang-chu', 'thong-bao', 'tuyen-dung', 'cap-nhat', 'su-kien'].includes(route)) {
      render();
    }
  }

  // ------------------------------------------------------------------
  // 11. Phien ban game hien tai o footer
  // ------------------------------------------------------------------
  async function loadFooterMeta() {
    try {
      const meta = await STOVN_API.getMeta();
      document.getElementById('footer-version').textContent = `Phien ban ${meta.gameVersion}`;
    } catch (e) { /* bo qua */ }
  }
  loadFooterMeta();
})();
