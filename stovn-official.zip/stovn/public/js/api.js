/**
 * js/api.js
 * Ham goi API dung chung cho toan bo trang cong khai.
 */
const STOVN_API = (() => {
  async function request(path, options = {}) {
    const res = await fetch(`/api${path}`, {
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      ...options
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(data.error || 'Da xay ra loi khong xac dinh.');
    }
    return data;
  }

  return {
    getAnnouncements(params = {}) {
      const qs = new URLSearchParams(params).toString();
      return request(`/announcements${qs ? `?${qs}` : ''}`);
    },
    getAnnouncement(id) {
      return request(`/announcements/${id}`);
    },
    getRecruitments() {
      return request('/recruitment');
    },
    getRecruitment(id) {
      return request(`/recruitment/${id}`);
    },
    submitApplication(payload) {
      return request('/applications', { method: 'POST', body: JSON.stringify(payload) });
    },
    getMeta() {
      return request('/meta');
    }
  };
})();
