/**
 * js/views.js
 * Cac ham render noi dung cho tung "trang" (view) cua ung dung mot-trang.
 * Moi ham tra ve chuoi HTML de main.js gan vao #app-root.
 */
const STOVN_VIEWS = (() => {
  const TYPE_LABELS = {
    'quan-trong': 'Quan trong',
    'bao-tri': 'Bao tri',
    'cap-nhat': 'Cap nhat',
    'khan-cap': 'Khan cap',
    'tuyen-dung': 'Tuyen dung',
    'su-kien': 'Su kien'
  };
  const STATUS_LABELS = {
    'dang-mo': 'Dang mo',
    'sap-dong': 'Sap dong',
    'da-dong': 'Da dong'
  };

  function formatDate(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleString('vi-VN', {
      day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit'
    });
  }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function excerpt(text, len = 130) {
    const clean = String(text || '');
    return clean.length > len ? `${clean.slice(0, len).trim()}…` : clean;
  }

  function announcementCard(item) {
    return `
      <article class="card glass-panel" data-open-announcement="${item.id}" tabindex="0">
        <div class="card-top-row">
          <span class="badge badge-${item.type}">${TYPE_LABELS[item.type] || item.type}</span>
        </div>
        <h3>${escapeHtml(item.title)}</h3>
        <p class="card-excerpt">${escapeHtml(excerpt(item.content))}</p>
        <div class="card-meta">
          <span>${escapeHtml(item.author)}</span>
          <span>${formatDate(item.createdAt)}</span>
        </div>
      </article>
    `;
  }

  function recruitmentCard(item) {
    const deadlinePassed = item.deadline && new Date(item.deadline) < new Date();
    return `
      <div class="job-card glass-panel">
        <div class="job-top">
          <h3>${escapeHtml(item.position)}</h3>
          <span class="badge badge-status-${item.status}">${STATUS_LABELS[item.status] || item.status}</span>
        </div>
        <div class="job-fields">
          <div>
            <div class="job-field-label">Dieu kien</div>
            <div class="job-field-value">${escapeHtml(item.requirements)}</div>
          </div>
          <div>
            <div class="job-field-label">Quyen loi</div>
            <div class="job-field-value">${escapeHtml(item.benefits)}</div>
          </div>
        </div>
        <div class="job-top">
          <span class="job-deadline">Han dang ky: ${formatDate(item.deadline)}${deadlinePassed ? ' (da het han)' : ''}</span>
          <button class="btn btn-primary btn-sm" data-open-apply="${item.id}" data-position="${escapeHtml(item.position)}"
            ${item.status !== 'dang-mo' || deadlinePassed ? 'disabled' : ''}>
            Dang ky
          </button>
        </div>
      </div>
    `;
  }

  function emptyState(label) {
    return `
      <div class="empty-state glass-panel">
        <span class="mark">KHONG CO DU LIEU</span>
        <p>${label}</p>
      </div>
    `;
  }

  async function home() {
    let meta = { gameVersion: '—', totalAnnouncements: 0, totalRecruitments: 0 };
    let latest = [];
    try {
      const [metaData, annData] = await Promise.all([
        STOVN_API.getMeta(),
        STOVN_API.getAnnouncements()
      ]);
      meta = metaData;
      latest = annData.items.slice(0, 3);
    } catch (e) { /* giu gia tri mac dinh neu API loi */ }

    return `
      <section class="view">
        <div class="hero">
          <div class="hero-console glass-panel">
            <div class="hero-eyebrow-row">
              <span class="status-chip"><span class="dot"></span>He thong dang hoat dong</span>
            </div>
            <h1>STOVN Official — Cong thong tin chinh thuc</h1>
            <p class="lead">Theo doi thong bao, cap nhat, tuyen dung va su kien cua game STOVN
              tai mot noi duy nhat. Moi noi dung duoc dong bo truc tiep, khong can tai lai trang.</p>
            <div class="hero-actions">
              <a href="#/thong-bao" class="btn btn-primary" data-nav-link>Xem thong bao</a>
              <a href="#/tuyen-dung" class="btn btn-ghost" data-nav-link>Tuyen dung</a>
            </div>
          </div>
          <div class="hero-side">
            <div class="stat-card glass-panel">
              <div class="stat-label">Phien ban hien tai</div>
              <div class="stat-value mono" id="home-version">${escapeHtml(meta.gameVersion)}</div>
            </div>
            <div class="stat-card glass-panel">
              <div class="stat-label">Tong so thong bao</div>
              <div class="stat-value" id="home-total-announcements">${meta.totalAnnouncements}</div>
            </div>
            <div class="stat-card glass-panel">
              <div class="stat-label">Dot tuyen dung dang mo</div>
              <div class="stat-value" id="home-total-recruitments">${meta.totalRecruitments}</div>
            </div>
          </div>
        </div>

        <div class="home-grid">
          <div class="panel glass-panel">
            <h2>Gioi thieu STOVN</h2>
            <p class="intro-text">STOVN la mot du an game duoc phat trien va van hanh boi mot doi ngu
              dam me, tap trung vao trai nghiem cong dong va cap nhat noi dung thuong xuyen.
              Trang STOVN Official la kenh thong tin <strong>chinh thuc va duy nhat</strong> de
              cong dong nam bat moi thay doi cua game mot cach nhanh chong va chinh xac.</p>
          </div>
          <div class="panel glass-panel">
            <h2>Tin moi nhat</h2>
            <div style="display:flex; flex-direction:column; gap:12px;">
              ${latest.length ? latest.map((item) => `
                <div data-open-announcement="${item.id}" style="cursor:pointer; padding:12px 0; border-bottom:1px solid var(--border-glass);">
                  <span class="badge badge-${item.type}" style="margin-bottom:6px; display:inline-block;">${TYPE_LABELS[item.type] || item.type}</span>
                  <div style="font-size:0.92rem;">${escapeHtml(item.title)}</div>
                  <div style="font-family:var(--font-mono); font-size:0.7rem; color:var(--grey-dim); margin-top:4px;">${formatDate(item.createdAt)}</div>
                </div>
              `).join('') : '<p style="color:var(--grey);">Chua co thong bao nao.</p>'}
            </div>
          </div>
        </div>
      </section>
    `;
  }

  async function announcementsList({ search = '', type = '' } = {}) {
    let items = [];
    let errored = false;
    try {
      const data = await STOVN_API.getAnnouncements({ search, type });
      items = data.items;
    } catch (e) { errored = true; }

    return `
      <section class="view">
        <div class="view-header">
          <span class="view-eyebrow">Kenh thong tin chinh thuc</span>
          <h1>Thong bao</h1>
          <p>Toan bo thong bao tu ban quan tri STOVN, cap nhat truc tiep theo thoi gian thuc.</p>
        </div>
        <div class="toolbar glass-panel">
          <input type="text" id="announcement-search" placeholder="Tim kiem thong bao..." value="${escapeHtml(search)}" />
          <select id="announcement-filter">
            <option value="">Tat ca loai</option>
            ${Object.entries(TYPE_LABELS).map(([val, label]) => `
              <option value="${val}" ${type === val ? 'selected' : ''}>${label}</option>
            `).join('')}
          </select>
        </div>
        <div class="card-grid" id="announcement-grid">
          ${errored ? emptyState('Khong the tai thong bao luc nay. Vui long thu lai sau.')
            : items.length ? items.map(announcementCard).join('') : emptyState('Khong tim thay thong bao phu hop.')}
        </div>
      </section>
    `;
  }

  async function recruitmentList() {
    let items = [];
    let errored = false;
    try {
      const data = await STOVN_API.getRecruitments();
      items = data.items;
    } catch (e) { errored = true; }

    return `
      <section class="view">
        <div class="view-header">
          <span class="view-eyebrow">Gia nhap doi ngu</span>
          <h1>Tuyen dung</h1>
          <p>Cac vi tri dang tuyen trong cong dong STOVN. Nhan Dang ky de gui don ung tuyen.</p>
        </div>
        <div class="card-grid" style="grid-template-columns:1fr;" id="recruitment-grid">
          ${errored ? emptyState('Khong the tai danh sach tuyen dung luc nay.')
            : items.length ? items.map(recruitmentCard).join('') : emptyState('Hien khong co dot tuyen dung nao.')}
        </div>
      </section>
    `;
  }

  function typeFilteredView({ type, title, eyebrow, desc }) {
    return async () => {
      let items = [];
      let errored = false;
      try {
        const data = await STOVN_API.getAnnouncements({ type });
        items = data.items;
      } catch (e) { errored = true; }

      return `
        <section class="view">
          <div class="view-header">
            <span class="view-eyebrow">${eyebrow}</span>
            <h1>${title}</h1>
            <p>${desc}</p>
          </div>
          <div class="card-grid">
            ${errored ? emptyState('Khong the tai du lieu luc nay.')
              : items.length ? items.map(announcementCard).join('') : emptyState('Chua co noi dung nao trong muc nay.')}
          </div>
        </section>
      `;
    };
  }

  const updates = typeFilteredView({
    type: 'cap-nhat',
    title: 'Cap nhat',
    eyebrow: 'Nhat ky phat trien',
    desc: 'Cac thay doi, tinh nang moi va sua loi duoc trien khai cho game STOVN.'
  });

  const events = typeFilteredView({
    type: 'su-kien',
    title: 'Su kien',
    eyebrow: 'Hoat dong cong dong',
    desc: 'Cac su kien dang va sap dien ra trong game STOVN.'
  });

  function rules() {
    const items = [
      { title: 'Ton trong cong dong', body: 'Khong xuc pham, phan biet, quay roi hoac de doa nguoi choi khac duoi bat ky hinh thuc nao.' },
      { title: 'Khong gian lan', body: 'Nghiem cam su dung phan mem hoac loi de dat loi the khong cong bang trong game.' },
      { title: 'Ngon ngu phu hop', body: 'Khong su dung ngon tu tuc tiu, kich dong bao luc hoac noi dung nhay cam.' },
      { title: 'Tai khoan ca nhan', title2: '', body: 'Moi nguoi choi chiu trach nhiem bao mat tai khoan cua minh. Khong chia se hoac mua ban tai khoan.' },
      { title: 'Tuan thu quyet dinh cua BQT', body: 'Ban Quan Tri co quyen canh cao, tam khoa hoac cam vinh vien tai khoan vi pham noi quy.' }
    ];
    return `
      <section class="view">
        <div class="view-header">
          <span class="view-eyebrow">Quy dinh cong dong</span>
          <h1>Noi quy</h1>
          <p>Cac quy dinh sau ap dung cho toan bo nguoi choi va thanh vien cong dong STOVN.</p>
        </div>
        <div class="static-list">
          ${items.map((item, i) => `
            <div class="static-item glass-panel">
              <h3><span class="num">0${i + 1}</span> ${escapeHtml(item.title)}</h3>
              <p>${escapeHtml(item.body)}</p>
            </div>
          `).join('')}
        </div>
      </section>
    `;
  }

  function guide() {
    const items = [
      { title: 'Bat dau choi', body: 'Tham gia may chu STOVN tren Roblox, hoan thanh huong dan nhap mon de nhan phan thuong khoi diem.' },
      { title: 'Theo doi thong bao', body: 'Ghe tham muc Thong bao thuong xuyen de khong bo lo cac dot bao tri hoac su kien quan trong.' },
      { title: 'Tham gia Discord', body: 'Ket noi may chu Discord chinh thuc de trao doi voi cong dong va nhan ho tro truc tiep.' },
      { title: 'Ung tuyen doi ngu', body: 'Neu muon dong gop cho STOVN, hay theo doi muc Tuyen dung va gui don ung tuyen khi co dot phu hop.' }
    ];
    return `
      <section class="view">
        <div class="view-header">
          <span class="view-eyebrow">Bat dau nhanh</span>
          <h1>Huong dan</h1>
          <p>Nhung buoc co ban de lam quen voi STOVN va cong dong.</p>
        </div>
        <div class="static-list">
          ${items.map((item, i) => `
            <div class="static-item glass-panel">
              <h3><span class="num">0${i + 1}</span> ${escapeHtml(item.title)}</h3>
              <p>${escapeHtml(item.body)}</p>
            </div>
          `).join('')}
        </div>
      </section>
    `;
  }

  function contact() {
    return `
      <section class="view">
        <div class="view-header">
          <span class="view-eyebrow">Ket noi voi chung toi</span>
          <h1>Lien he</h1>
          <p>Can ho tro hoac co thac mac? Lien he Ban Quan Tri STOVN qua cac kenh ben duoi.</p>
        </div>
        <div class="contact-grid">
          <div class="contact-card glass-panel">
            <div class="label">Discord</div>
            <div class="value">discord.gg/stovn-official</div>
          </div>
          <div class="contact-card glass-panel">
            <div class="label">Email ho tro</div>
            <div class="value">support@stovn-official.example</div>
          </div>
          <div class="contact-card glass-panel">
            <div class="label">Roblox</div>
            <div class="value">STOVN Group Page</div>
          </div>
          <div class="contact-card glass-panel">
            <div class="label">Gio ho tro</div>
            <div class="value">09:00 — 23:00 hang ngay</div>
          </div>
        </div>
      </section>
    `;
  }

  return {
    TYPE_LABELS, STATUS_LABELS, formatDate, escapeHtml,
    home, announcementsList, recruitmentList, updates, events, rules, guide, contact
  };
})();
