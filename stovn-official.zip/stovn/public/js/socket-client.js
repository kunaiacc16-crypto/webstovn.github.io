/**
 * js/socket-client.js
 * Ket noi Socket.IO de nhan du lieu thoi gian thuc tu server (thong bao,
 * tuyen dung, cap nhat phien ban) va cap nhat giao dien ngay lap tuc,
 * khong can nguoi dung tai lai trang.
 */
const STOVN_SOCKET = io();

STOVN_SOCKET.on('connect', () => {
  document.dispatchEvent(new CustomEvent('stovn:socket-ready'));
});

STOVN_SOCKET.on('announcement:new', (item) => {
  document.dispatchEvent(new CustomEvent('stovn:announcement-new', { detail: item }));
});
STOVN_SOCKET.on('announcement:update', (item) => {
  document.dispatchEvent(new CustomEvent('stovn:announcement-update', { detail: item }));
});
STOVN_SOCKET.on('announcement:delete', (payload) => {
  document.dispatchEvent(new CustomEvent('stovn:announcement-delete', { detail: payload }));
});

STOVN_SOCKET.on('recruitment:new', (item) => {
  document.dispatchEvent(new CustomEvent('stovn:recruitment-new', { detail: item }));
});
STOVN_SOCKET.on('recruitment:update', (item) => {
  document.dispatchEvent(new CustomEvent('stovn:recruitment-update', { detail: item }));
});
STOVN_SOCKET.on('recruitment:delete', (payload) => {
  document.dispatchEvent(new CustomEvent('stovn:recruitment-delete', { detail: payload }));
});

STOVN_SOCKET.on('meta:update', (meta) => {
  document.dispatchEvent(new CustomEvent('stovn:meta-update', { detail: meta }));
});
