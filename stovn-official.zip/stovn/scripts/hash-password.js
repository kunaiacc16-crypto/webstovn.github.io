/**
 * scripts/hash-password.js
 * Cong cu dong lenh de tao chuoi bam (hash) bcrypt tu mat khau ban nhap,
 * de dan vao bien moi truong ADMIN_PASSWORD_HASH trong file .env
 *
 * Cach dung:
 *   npm run hash-password
 *   (roi nhap mat khau khi duoc hoi)
 */

const bcrypt = require('bcryptjs');
const readline = require('readline');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

rl.question('Nhap mat khau muon dat cho admin: ', (password) => {
  if (!password || password.length < 6) {
    console.error('Mat khau nen co it nhat 6 ky tu. Vui long chay lai lenh.');
    rl.close();
    process.exit(1);
  }
  const hash = bcrypt.hashSync(password, 12);
  console.log('\nDa tao xong. Dan dong duoi day vao file .env cua ban:\n');
  console.log(`ADMIN_PASSWORD_HASH=${hash}\n`);
  rl.close();
});
