/**
 * middleware/auth.js
 * Kiem tra quan tri vien da dang nhap (dua vao session) truoc khi cho phep
 * truy cap cac API chinh sua du lieu (dang/sua/xoa thong bao, tuyen dung...).
 */

function requireAdmin(req, res, next) {
  if (req.session && req.session.isAdmin) {
    return next();
  }
  return res.status(401).json({ error: 'Ban chua dang nhap quan tri.' });
}

/**
 * Kiem tra token CSRF gui kem trong header "x-csrf-token" khop voi token
 * duoc luu trong session cua nguoi dung hien tai. Bao ve cac request
 * thay doi du lieu (POST/PUT/PATCH/DELETE) khoi tan cong CSRF.
 */
function requireCsrf(req, res, next) {
  const tokenFromClient = req.headers['x-csrf-token'];
  if (!req.session || !req.session.csrfToken || tokenFromClient !== req.session.csrfToken) {
    return res.status(403).json({ error: 'Token bao mat khong hop le. Vui long tai lai trang.' });
  }
  return next();
}

module.exports = { requireAdmin, requireCsrf };
