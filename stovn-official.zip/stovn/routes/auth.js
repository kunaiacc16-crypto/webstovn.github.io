const express = require('express');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const { nanoid } = require('nanoid');

const router = express.Router();

// Gioi han so lan dang nhap sai de chong do mat khau (brute force).
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 phut
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Ban thu dang nhap qua nhieu lan. Vui long thu lai sau it phut.' }
});

router.post('/login', loginLimiter, async (req, res) => {
  const { username, password } = req.body || {};

  if (!username || !password) {
    return res.status(400).json({ error: 'Vui long nhap day du ten dang nhap va mat khau.' });
  }

  const validUsername = process.env.ADMIN_USERNAME || 'stovnkeyadmin';
  const passwordHash = process.env.ADMIN_PASSWORD_HASH;

  if (!passwordHash) {
    console.error('ADMIN_PASSWORD_HASH chua duoc thiet lap trong .env');
    return res.status(500).json({ error: 'He thong dang nhap chua duoc cau hinh. Lien he quan tri he thong.' });
  }

  if (username !== validUsername) {
    return res.status(401).json({ error: 'Ten dang nhap hoac mat khau khong dung.' });
  }

  const match = await bcrypt.compare(password, passwordHash);
  if (!match) {
    return res.status(401).json({ error: 'Ten dang nhap hoac mat khau khong dung.' });
  }

  req.session.isAdmin = true;
  req.session.username = username;
  req.session.csrfToken = nanoid(32);

  return res.json({ success: true, csrfToken: req.session.csrfToken });
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('connect.sid');
    res.json({ success: true });
  });
});

router.get('/session', (req, res) => {
  if (req.session && req.session.isAdmin) {
    return res.json({ authenticated: true, username: req.session.username, csrfToken: req.session.csrfToken });
  }
  return res.json({ authenticated: false });
});

module.exports = router;
