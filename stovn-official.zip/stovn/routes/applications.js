const express = require('express');
const sanitizeHtml = require('sanitize-html');
const rateLimit = require('express-rate-limit');
const db = require('../database/db');
const { requireAdmin, requireCsrf } = require('../middleware/auth');

const VALID_STATUS = ['cho-duyet', 'da-duyet', 'tu-choi'];

function clean(text) {
  return sanitizeHtml(String(text || ''), { allowedTags: [], allowedAttributes: {} }).trim();
}

// Gioi han so don gui de tranh spam tu mot nguoi dung.
const submitLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 gio
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Ban da gui qua nhieu don dang ky. Vui long thu lai sau.' }
});

module.exports = function applicationsRouter(io) {
  const router = express.Router();

  // Nguoi dung gui don dang ky tuyen dung — khong can dang nhap.
  router.post('/', submitLimiter, async (req, res) => {
    const { recruitmentId, robloxName, discordName, currentRank, age, reason } = req.body || {};

    if (!robloxName || !discordName || !currentRank || !age || !reason) {
      return res.status(400).json({ error: 'Vui long dien day du thong tin dang ky.' });
    }

    const ageNumber = parseInt(age, 10);
    if (Number.isNaN(ageNumber) || ageNumber < 1 || ageNumber > 120) {
      return res.status(400).json({ error: 'Tuoi khong hop le.' });
    }

    if (recruitmentId) {
      const job = db.recruitments.getById(recruitmentId);
      if (!job) return res.status(404).json({ error: 'Dot tuyen dung khong ton tai.' });
    }

    const item = await db.applications.add({
      recruitmentId: recruitmentId || null,
      robloxName: clean(robloxName).slice(0, 100),
      discordName: clean(discordName).slice(0, 100),
      currentRank: clean(currentRank).slice(0, 100),
      age: ageNumber,
      reason: clean(reason).slice(0, 2000),
      status: 'cho-duyet'
    });

    // Bao cho quan tri vien dang mo trang admin biet co don moi.
    io.emit('application:new-for-admin', item);

    res.status(201).json({ success: true, message: 'Da gui don dang ky thanh cong.', id: item.id });
  });

  // Cac route ben duoi chi danh cho quan tri vien.
  router.get('/', requireAdmin, (req, res) => {
    const { status } = req.query;
    let list = db.applications.getAll();
    if (status && VALID_STATUS.includes(status)) {
      list = list.filter((item) => item.status === status);
    }
    res.json({ items: list, total: list.length });
  });

  router.put('/:id', requireAdmin, requireCsrf, async (req, res) => {
    const { status } = req.body || {};
    if (!VALID_STATUS.includes(status)) {
      return res.status(400).json({ error: 'Trang thai khong hop le.' });
    }
    const updated = await db.applications.update(req.params.id, { status });
    if (!updated) return res.status(404).json({ error: 'Khong tim thay don dang ky.' });

    io.emit('application:update-for-admin', updated);
    res.json(updated);
  });

  router.delete('/:id', requireAdmin, requireCsrf, async (req, res) => {
    const ok = await db.applications.remove(req.params.id);
    if (!ok) return res.status(404).json({ error: 'Khong tim thay don dang ky.' });

    io.emit('application:delete-for-admin', { id: req.params.id });
    res.json({ success: true });
  });

  return router;
};
