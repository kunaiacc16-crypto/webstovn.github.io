const express = require('express');
const sanitizeHtml = require('sanitize-html');
const db = require('../database/db');
const { requireAdmin, requireCsrf } = require('../middleware/auth');

const VALID_TYPES = ['quan-trong', 'bao-tri', 'cap-nhat', 'khan-cap', 'tuyen-dung', 'su-kien'];

function clean(text) {
  // Loai bo the HTML/script de chong XSS, chi giu lai van ban thuan.
  return sanitizeHtml(String(text || ''), { allowedTags: [], allowedAttributes: {} }).trim();
}

module.exports = function announcementsRouter(io) {
  const router = express.Router();

  // Cong khai: lay danh sach thong bao (ho tro tim kiem & loc theo loai)
  router.get('/', (req, res) => {
    const { search, type } = req.query;
    let list = db.announcements.getAll();

    if (type && VALID_TYPES.includes(type)) {
      list = list.filter((item) => item.type === type);
    }
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(
        (item) => item.title.toLowerCase().includes(q) || item.content.toLowerCase().includes(q)
      );
    }
    res.json({ items: list, total: list.length });
  });

  router.get('/:id', (req, res) => {
    const item = db.announcements.getById(req.params.id);
    if (!item) return res.status(404).json({ error: 'Khong tim thay thong bao.' });
    res.json(item);
  });

  // Cac route ben duoi chi danh cho quan tri vien da dang nhap.
  router.post('/', requireAdmin, requireCsrf, async (req, res) => {
    const { title, content, type, author } = req.body || {};
    if (!title || !content || !VALID_TYPES.includes(type)) {
      return res.status(400).json({ error: 'Thieu tieu de, noi dung, hoac loai thong bao khong hop le.' });
    }
    const item = await db.announcements.add({
      title: clean(title).slice(0, 200),
      content: clean(content).slice(0, 5000),
      type,
      author: clean(author || 'Ban Quan Tri STOVN').slice(0, 100)
    });

    io.emit('announcement:new', item);
    res.status(201).json(item);
  });

  router.put('/:id', requireAdmin, requireCsrf, async (req, res) => {
    const { title, content, type, author } = req.body || {};
    const patch = {};
    if (title) patch.title = clean(title).slice(0, 200);
    if (content) patch.content = clean(content).slice(0, 5000);
    if (type && VALID_TYPES.includes(type)) patch.type = type;
    if (author) patch.author = clean(author).slice(0, 100);

    const updated = await db.announcements.update(req.params.id, patch);
    if (!updated) return res.status(404).json({ error: 'Khong tim thay thong bao.' });

    io.emit('announcement:update', updated);
    res.json(updated);
  });

  router.delete('/:id', requireAdmin, requireCsrf, async (req, res) => {
    const ok = await db.announcements.remove(req.params.id);
    if (!ok) return res.status(404).json({ error: 'Khong tim thay thong bao.' });

    io.emit('announcement:delete', { id: req.params.id });
    res.json({ success: true });
  });

  return router;
};
