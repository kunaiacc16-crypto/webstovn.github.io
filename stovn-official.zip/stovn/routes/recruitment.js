const express = require('express');
const sanitizeHtml = require('sanitize-html');
const db = require('../database/db');
const { requireAdmin, requireCsrf } = require('../middleware/auth');

const VALID_STATUS = ['dang-mo', 'sap-dong', 'da-dong'];

function clean(text) {
  return sanitizeHtml(String(text || ''), { allowedTags: [], allowedAttributes: {} }).trim();
}

module.exports = function recruitmentRouter(io) {
  const router = express.Router();

  router.get('/', (req, res) => {
    const list = db.recruitments.getAll();
    res.json({ items: list, total: list.length });
  });

  router.get('/:id', (req, res) => {
    const item = db.recruitments.getById(req.params.id);
    if (!item) return res.status(404).json({ error: 'Khong tim thay dot tuyen dung.' });
    res.json(item);
  });

  router.post('/', requireAdmin, requireCsrf, async (req, res) => {
    const { position, requirements, benefits, deadline, status } = req.body || {};
    if (!position || !requirements || !benefits || !deadline) {
      return res.status(400).json({ error: 'Vui long dien day du thong tin dot tuyen dung.' });
    }
    const item = await db.recruitments.add({
      position: clean(position).slice(0, 150),
      requirements: clean(requirements).slice(0, 3000),
      benefits: clean(benefits).slice(0, 3000),
      deadline,
      status: VALID_STATUS.includes(status) ? status : 'dang-mo'
    });

    io.emit('recruitment:new', item);
    res.status(201).json(item);
  });

  router.put('/:id', requireAdmin, requireCsrf, async (req, res) => {
    const { position, requirements, benefits, deadline, status } = req.body || {};
    const patch = {};
    if (position) patch.position = clean(position).slice(0, 150);
    if (requirements) patch.requirements = clean(requirements).slice(0, 3000);
    if (benefits) patch.benefits = clean(benefits).slice(0, 3000);
    if (deadline) patch.deadline = deadline;
    if (status && VALID_STATUS.includes(status)) patch.status = status;

    const updated = await db.recruitments.update(req.params.id, patch);
    if (!updated) return res.status(404).json({ error: 'Khong tim thay dot tuyen dung.' });

    io.emit('recruitment:update', updated);
    res.json(updated);
  });

  router.delete('/:id', requireAdmin, requireCsrf, async (req, res) => {
    const ok = await db.recruitments.remove(req.params.id);
    if (!ok) return res.status(404).json({ error: 'Khong tim thay dot tuyen dung.' });

    io.emit('recruitment:delete', { id: req.params.id });
    res.json({ success: true });
  });

  return router;
};
