const express = require('express');
const db = require('../database/db');
const { requireAdmin, requireCsrf } = require('../middleware/auth');

module.exports = function metaRouter(io) {
  const router = express.Router();

  router.get('/', (req, res) => {
    const meta = db.getMeta();
    res.json({
      gameVersion: meta.gameVersion || '1.0.0',
      totalAnnouncements: db.announcements.getAll().length,
      totalRecruitments: db.recruitments.getAll().filter((r) => r.status === 'dang-mo').length
    });
  });

  router.put('/', requireAdmin, requireCsrf, async (req, res) => {
    const { gameVersion } = req.body || {};
    if (!gameVersion) return res.status(400).json({ error: 'Thieu phien ban game.' });
    const meta = await db.setMeta({ gameVersion: String(gameVersion).slice(0, 30) });

    io.emit('meta:update', meta);
    res.json(meta);
  });

  return router;
};
