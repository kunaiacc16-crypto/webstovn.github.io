/**
 * database/db.js
 * ----------------------------------------------------------------------
 * Lop luu tru du lieu dang file JSON, mo phong theo interface cua
 * Firestore (collection / doc / add / get / update / delete) de sau nay
 * co the thay the bang Firebase Firestore hoac Supabase ma KHONG can sua
 * lai code trong routes/*.js — chi can viet lai file nay.
 *
 * Neu muon dung Firebase that su, xem huong dan trong README.md.
 * ----------------------------------------------------------------------
 */

const fs = require('fs');
const path = require('path');
const { nanoid } = require('nanoid');

const DATA_FILE = path.join(__dirname, 'data.json');

// Doc du lieu tu dia. Neu file chua ton tai, tao du lieu mac dinh.
function loadData() {
  if (!fs.existsSync(DATA_FILE)) {
    const seed = {
      announcements: [],
      recruitments: [],
      applications: [],
      meta: { gameVersion: '1.0.0', createdAt: new Date().toISOString() }
    };
    fs.writeFileSync(DATA_FILE, JSON.stringify(seed, null, 2), 'utf-8');
    return seed;
  }
  const raw = fs.readFileSync(DATA_FILE, 'utf-8');
  try {
    return JSON.parse(raw);
  } catch (err) {
    console.error('Loi doc database/data.json, khoi tao lai du lieu rong.', err);
    return { announcements: [], recruitments: [], applications: [], meta: {} };
  }
}

let state = loadData();

// Ghi toan bo state xuong dia. Dung khoa ghi tuan tu don gian de tranh ghi de.
let writeQueue = Promise.resolve();
function persist() {
  writeQueue = writeQueue.then(() => {
    return new Promise((resolve, reject) => {
      fs.writeFile(DATA_FILE, JSON.stringify(state, null, 2), 'utf-8', (err) => {
        if (err) return reject(err);
        resolve();
      });
    });
  });
  return writeQueue;
}

/**
 * Lop Collection dung chung cho announcements / recruitments / applications.
 * Cung cap cac ham: getAll, getById, add, update, remove.
 */
class Collection {
  constructor(name) {
    this.name = name;
  }

  getAll() {
    return [...state[this.name]].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  getById(id) {
    return state[this.name].find((item) => item.id === id) || null;
  }

  async add(data) {
    const item = {
      id: nanoid(10),
      ...data,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    state[this.name].push(item);
    await persist();
    return item;
  }

  async update(id, patch) {
    const idx = state[this.name].findIndex((item) => item.id === id);
    if (idx === -1) return null;
    state[this.name][idx] = {
      ...state[this.name][idx],
      ...patch,
      updatedAt: new Date().toISOString()
    };
    await persist();
    return state[this.name][idx];
  }

  async remove(id) {
    const before = state[this.name].length;
    state[this.name] = state[this.name].filter((item) => item.id !== id);
    await persist();
    return state[this.name].length < before;
  }
}

const announcements = new Collection('announcements');
const recruitments = new Collection('recruitments');
const applications = new Collection('applications');

function getMeta() {
  return state.meta;
}

async function setMeta(patch) {
  state.meta = { ...state.meta, ...patch };
  await persist();
  return state.meta;
}

module.exports = {
  announcements,
  recruitments,
  applications,
  getMeta,
  setMeta
};
