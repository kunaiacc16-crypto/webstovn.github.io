# STOVN Official

Trang thong bao chinh thuc cua game STOVN — thong bao, cap nhat, tuyen dung,
su kien, noi quy va huong dan, dong bo theo thoi gian thuc, khong can dang
nhap de xem.

## Cong nghe

- **Frontend**: HTML5, CSS3 (glassmorphism, animation), JavaScript ES6 (SPA
  dinh tuyen bang hash, tu nhan dien thiet bi mobile/desktop).
- **Backend**: Node.js + Express.
- **Realtime**: Socket.IO — moi thay doi cua admin (dang/sua/xoa thong bao,
  tuyen dung, cap nhat phien ban) duoc day ngay den moi nguoi dang mo web.
- **Du lieu**: mac dinh dung file JSON cuc nhe (`database/data.json`) qua
  mot lop truy xuat co interface giong Firestore, de co the thay bang
  Firebase Firestore hoac Supabase that su ma khong sua code trong `routes/`.
- **Bao mat**: Helmet (CSP/security headers), express-rate-limit (chong do
  mat khau & spam don dang ky), sanitize-html (chong XSS), CSRF token rieng
  cho tung phien quan tri, mat khau admin duoc bam bang bcrypt (khong luu
  dang van ban).

## Cai dat

```bash
npm install
cp .env.example .env
```

Mo file `.env` va dien:

- `SESSION_SECRET`: mot chuoi ngau nhien, dai, kho doan.
- `ADMIN_USERNAME`: mac dinh la `stovnkeyadmin` (co the doi).
- `ADMIN_PASSWORD_HASH`: chay lenh sau va dan ket qua vao:

```bash
npm run hash-password
```

## Chay thu

```bash
npm run dev     # co tu dong tai lai khi sua code (can nodemon)
# hoac
npm start
```

Mo trinh duyet:

- Trang chinh: `http://localhost:3000`
- Trang quan tri: `http://localhost:3000/admin`

Dang nhap trang quan tri bang `ADMIN_USERNAME` va mat khau (dang chua bam)
tuong ung voi `ADMIN_PASSWORD_HASH` ban da tao o buoc tren.

## Cau truc thu muc

```
stovn/
  server.js                 Server chinh (Express + Socket.IO)
  database/
    db.js                   Lop truy xuat du lieu (interface kieu Firestore)
    data.json                Du lieu mau, tu tao khi chay lan dau
  routes/
    auth.js                 Dang nhap / dang xuat / kiem tra phien admin
    announcements.js         API thong bao (cong khai doc, admin ghi)
    recruitment.js           API tuyen dung
    applications.js          API don dang ky tuyen dung
    meta.js                  API phien ban game / thong ke trang chu
  middleware/
    auth.js                 Kiem tra dang nhap admin + token CSRF
  scripts/
    hash-password.js         Cong cu tao mat khau da bam cho admin
  public/
    index.html, css/, js/    Giao dien cong khai (SPA)
    admin/                   Giao dien trang quan tri
```

## Chuyen sang Firebase Firestore hoac Supabase

Toan bo logic doc/ghi du lieu deu di qua `database/db.js` voi 4 ham dung
chung cho moi collection: `getAll`, `getById`, `add`, `update`, `remove`.
De chuyen sang Firestore that su:

1. Cai dat `firebase-admin`.
2. Viet lai noi dung `database/db.js` de moi ham goi Firestore SDK thay vi
   doc/ghi file JSON (giu nguyen ten ham va kieu du lieu tra ve).
3. Bat Firestore that-time listener (`onSnapshot`) o phia server va emit
   qua Socket.IO giong nhu hien tai — khong can sua `routes/*.js`.

Voi Supabase, thay `firebase-admin` bang `@supabase/supabase-js` va dung
tinh nang Supabase Realtime (Postgres Changes) theo cach tuong tu.

## Trien khai (deploy)

Du an co the trien khai len bat ky nen tang ho tro Node.js lau dai
(long-running process) vi can Socket.IO, vi du: Railway, Render, VPS
(PM2 + Nginx reverse proxy). Luu y:

- Dat `NODE_ENV=production` de bat cookie session bao mat (`secure`).
- Neu chay sau reverse proxy (Nginx, Cloudflare...), dam bao proxy cho
  phep WebSocket upgrade cho duong dan `/socket.io/`.
- Khong commit file `.env` len kho ma nguon.

## Ghi chu bao mat

- Mat khau admin khong bao gio duoc luu hoac ghi dang van ban trong ma
  nguon; chi luu ban bam (hash) bcrypt trong bien moi truong.
- Tat ca noi dung nguoi dung nhap (thong bao, don dang ky...) deu duoc
  loc bo the HTML/script truoc khi luu, chong tan cong XSS.
- Cac request thay doi du lieu tu trang quan tri deu phai kem token CSRF
  duoc cap rieng cho tung phien dang nhap.
- Nen bo sung HTTPS (qua reverse proxy hoac nen tang hosting) khi trien
  khai thuc te de bao ve du lieu tren duong truyen.
